package je16; // Corregido: Ahora pertenece al paquete je16

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author usuario
 */
public enum TipoCuenta {
    AHORRO,
    NOMINA,
    EMPRESARIAL
}