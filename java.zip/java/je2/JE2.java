package je2;

/**
 *
 * @author usuario
 */
public class JE2 {
    public static void main(String[] args) {
        // Creamos una cuenta bancaria
        CuentaBancaria cuentaOriginal = new CuentaBancaria("Cesar Sanchez Martinez",    1500.0, "987654321");

        // Otra variable de referencia que apunta al mismo objeto
        CuentaBancaria cuentaAlias = cuentaOriginal;

        // Modificamos el objeto usando la referencia 'cuentaAlias'
        cuentaAlias.depositar(300);

        // Se reflejará en ambas referencias, ya que apuntan al mismo objeto
        System.out.println("Desde cuentaOriginal:");
        cuentaOriginal.mostrarInformacion();

        System.out.println("\nDesde cuentaAlias:");
        cuentaAlias.mostrarInformacion();

        System.out.println("Cesar Sanchez Martinez - 24598 - 3C");
    }
}