package je3;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author usuario
 */
public class CuentaBancaria {
    // Variables de instancia (cada objeto tiene sus propios valores)
    private String titular;
    private double saldo;
    private String numeroCuenta;

    // Constructor
    public CuentaBancaria(String titular, double saldoInicial, String numeroCuenta) {
        this.titular = titular;
        this.saldo = saldoInicial;
        this.numeroCuenta = numeroCuenta;
    }

    // Método sin parámetros ni retorno
    public void mostrarSaldo() {
        System.out.println("Saldo actual de " + titular + ": $" + saldo);
    }

    public void depositar(double cantidad) {
        System.out.println("Depósito exitoso: $" + cantidad);
        saldo += cantidad;
    }

    // Método con retorno
    public double obtenerSaldo() {
        return saldo;
    }
}