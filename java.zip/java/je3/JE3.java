package je3;

/**
 * @author usuario
 */
public class JE3 {
    public static void main(String[] args) {
        CuentaBancaria cuenta = new CuentaBancaria("Luis Torres", 2000.0, "654321987");

        // Llamada a método sin parámetros
        cuenta.mostrarSaldo();

        // Llamada a método con parámetro
        cuenta.depositar(500);

        // Llamada a método que devuelve un valor
        double saldoActual = cuenta.obtenerSaldo();
        System.out.println("El saldo consultado es: $" + saldoActual);
        System.out.println("Cesar Sanchez Martinez - 24598 - 3C"); // Código añadido
    }
}