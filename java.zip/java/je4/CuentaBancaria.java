package je4;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author usuario
 */
public class CuentaBancaria {
    // Variables de instancia (cada objeto tiene sus propios valores)
    private String titular;
    private double saldo;
    private String numeroCuenta;

    // Constructor
    public CuentaBancaria(String titular, double saldoInicial, String numeroCuenta) {
        this.titular = titular;
        this.saldo = saldoInicial;
        this.numeroCuenta = numeroCuenta;
    }

    // Métodos
    public void depositar(double cantidad) {
        saldo += cantidad;
    }

    public void retirar(double cantidad) {
        if (cantidad <= saldo) {
            saldo -= cantidad;
        } else {
            System.out.println("Fondos insuficientes.");
        }
    }

    // Método que devuelve el saldo actual
    public double obtenerSaldo() {
        return saldo;
    }

    // Método que devuelve si la cuenta está en números rojos
    public boolean estaEnRojo() {
        return saldo < 0;
    }
}