package je4;

/**
 *
 * @author usuario
 */
public class JE4 {

    public static void main(String[] args) {
        CuentaBancaria cuenta = new CuentaBancaria("María Gómez", 300.0, "111222333");

        cuenta.retirar(400); // Intenta dejar saldo negativo

        // Obtener saldo usando return
        double saldoActual = cuenta.obtenerSaldo();
        System.out.println("Saldo actual: $" + saldoActual);

        // Evaluar si la cuenta está en números rojos
        if (cuenta.estaEnRojo()) {
            System.out.println("Advertencia: La cuenta está en números rojos.");
        } else {
            System.out.println("La cuenta está en buen estado.");
        }
        System.out.println("Cesar Sanchez Martinez - 24598 - 3C"); // Código añadido
    }
}