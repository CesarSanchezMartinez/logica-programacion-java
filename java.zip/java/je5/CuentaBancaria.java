

package je5;

/*
 * La clase CuentaBancaria con todas las funcionalidades desarrolladas hasta la Práctica 5.
 */

/**
 *
 * @author usuario
 */
public class CuentaBancaria {
    // Variables de instancia (cada objeto tiene sus propios valores)
    private String titular;
    private double saldo;
    private String numeroCuenta;

    // Constructor
    public CuentaBancaria(String titular, double saldoInicial, String numeroCuenta) {
        this.titular = titular;
        this.saldo = saldoInicial;
        this.numeroCuenta = numeroCuenta;
    }

    // Métodos (incluyendo los de prácticas anteriores)

    public void depositar(double cantidad) {
        saldo += cantidad;
        // La impresión del mensaje "Depósito exitoso" podría ir aquí o en el main para Práctica 3
        // System.out.println("Depósito exitoso: $" + cantidad);
    }

    public void retirar(double cantidad) {
        if (cantidad <= saldo) {
            saldo -= cantidad;
        } else {
            System.out.println("Fondos insuficientes.");
        }
    }

    public void mostrarInformacion() {
        System.out.println("Titular: " + titular);
        System.out.println("Número de cuenta: " + numeroCuenta);
        System.out.println("Saldo actual: $" + saldo);
    }

    // Método que devuelve el saldo actual (introducido en Práctica 4)
    public double obtenerSaldo() {
        return saldo;
    }

    // Método que devuelve si la cuenta está en números rojos (introducido en Práctica 4)
    public boolean estaEnRojo() {
        return saldo < 0;
    }

    // Nuevo método para la Práctica 5: transferir
    public void transferir(double cantidad, CuentaBancaria destino) {
        if (cantidad <= this.saldo) {
            this.saldo -= cantidad;
            destino.depositar(cantidad);
            System.out.println("Transferencia exitosa de $" + cantidad + " de " + this.titular + " a " + destino.titular);
        } else {
            System.out.println("Fondos insuficientes para la transferencia desde la cuenta de " + this.titular + ".");
        }
    }
}