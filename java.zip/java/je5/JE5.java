package je5;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */

/**
 *
 * @author usuario
 */
public class JE5 {

    public static void main(String[] args) {
        CuentaBancaria cuenta1 = new CuentaBancaria("Pedro Sánchez", 1000.0, "111111111");
        CuentaBancaria cuenta2 = new CuentaBancaria("Laura Díaz", 500.0, "222222222");

        cuenta1.transferir(300, cuenta2); // Transferencia entre cuentas usando parámetros

        System.out.println("\n--- Estado final ---");
        cuenta1.mostrarInformacion();
        cuenta2.mostrarInformacion();
        System.out.println("Cesar Sanchez Martinez - 24598 - 3C"); // Código añadido
    }
}