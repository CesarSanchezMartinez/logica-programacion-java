package je6;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author usuario
 */
public class CuentaBancaria {
    private String titular;
    private double saldo;
    private String numeroCuenta;

    // Constructor completo
    public CuentaBancaria(String titular, double saldoInicial, String numeroCuenta) {
        this.titular = titular;
        this.saldo = saldoInicial;
        this.numeroCuenta = numeroCuenta;
    }

    // Constructor con solo titular y número de cuenta (saldo por defecto)
    public CuentaBancaria(String titular, String numeroCuenta) {
        this.titular = titular;
        this.numeroCuenta = numeroCuenta;
        this.saldo = 0.0; // Saldo por defecto
    }

    // Constructor vacío (valores por defecto)
    public CuentaBancaria() {
        this.titular = "Desconocido";
        this.numeroCuenta = "000000000";
        this.saldo = 0.0;
    }

    public void mostrarInformacion() {
        System.out.println("Titular: " + titular);
        System.out.println("Número de cuenta: " + numeroCuenta);
        System.out.println("Saldo: $" + saldo);
    }

    // Otros métodos como depositar, retirar, obtenerSaldo, estaEnRojo, transferir
    // (asumiendo que se heredan o se copian de versiones anteriores si es necesario
    // para compilar con JE6, aunque no se muestran en las imágenes específicas de je6)
}