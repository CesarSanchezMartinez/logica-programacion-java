package je6;

/**
 *
 * @author usuario
 */
public class JE6 {
    public static void main(String[] args) {
        // Usando constructor completo
        CuentaBancaria cuenta1 = new CuentaBancaria("Carlos Mendoza", 1500.0, "333333333");

        // Usando constructor con saldo por defecto
        CuentaBancaria cuenta2 = new CuentaBancaria("Lucia Herrera", "444444444");

        // Usando constructor vacío
        CuentaBancaria cuenta3 = new CuentaBancaria();

        cuenta1.mostrarInformacion();
        System.out.println("---");
        cuenta2.mostrarInformacion();
        System.out.println("---");
        cuenta3.mostrarInformacion();
        System.out.println("Cesar Sanchez Martinez - 24598 - 3C"); // Código añadido
    }
}
