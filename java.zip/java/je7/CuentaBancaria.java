package je7;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author usuario
 */
public class CuentaBancaria {
    private String titular; //
    private double saldo; //
    private String numeroCuenta; //

    // Constante: límite máximo de retiro diario
    public static final double LIMITE_RETIRO_DIARIO = 10000.0; //

    public CuentaBancaria(String titular, double saldoInicial, String numeroCuenta) { //
        this.titular = titular; //
        this.saldo = saldoInicial; //
        this.numeroCuenta = numeroCuenta; //
    }

    public void retirar(double cantidad) { //
        if (cantidad <= 0) { //
            System.out.println("Error: La cantidad a retirar debe ser mayor que cero."); //
        } else if (cantidad > LIMITE_RETIRO_DIARIO) { //
            System.out.println("Error: No se puede retirar más de $" + LIMITE_RETIRO_DIARIO + " en un día."); //
        } else if (cantidad <= saldo) { //
            saldo -= cantidad; //
            System.out.println("Se retiraron $" + cantidad); //
        } else { //
            System.out.println("Fondos insuficientes."); //
        }
    }

    public void mostrarInformacion() { //
        System.out.println("Titular: " + titular); //
        System.out.println("Número de cuenta: " + numeroCuenta); //
        System.out.println("Saldo actual: $" + saldo); //
    }
    // Otros métodos como depositar, obtenerSaldo, estaEnRojo, transferir
    // (asumiendo que se heredan o se copian de versiones anteriores si es necesario
    // para compilar con JE7, aunque no se muestran en las imágenes específicas de je7)
}