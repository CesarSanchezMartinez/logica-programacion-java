package je7;

/**
 *
 * @author usuario
 */
public class JE7 {
    public static void main(String[] args) {
        CuentaBancaria cuenta = new CuentaBancaria("Roberto Vázquez", 12000.0, "777888999"); //

        // Intento de retiro dentro del límite
        cuenta.retirar(3000); //

        // Intento de retiro fuera del límite
        cuenta.retirar(15000); //

        cuenta.mostrarInformacion(); //

        // Mostrar constante directamente
        System.out.println("Límite diario de retiro permitido: $" + CuentaBancaria.LIMITE_RETIRO_DIARIO); //
        System.out.println("Cesar Sanchez Martinez - 24598 - 3C"); // Código añadido
    }
}