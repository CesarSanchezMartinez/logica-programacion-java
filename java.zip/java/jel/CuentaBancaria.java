package jel; //

/**
 * //
 * //
 * @author usuario //
 */
public class CuentaBancaria { //
    // Variables de instancia (cada objeto tiene sus propios valores) //
    private String titular; //
    private double saldo; //
    private String numeroCuenta; //

    // Constructor //
    public CuentaBancaria(String titular, double saldoInicial, String numeroCuenta) { //
        this.titular = titular; //
        this.saldo = saldoInicial; //
        this.numeroCuenta = numeroCuenta; //
    } //

    // Métodos //
    public void depositar(double cantidad) { //
        saldo += cantidad; //
    } //

    public void retirar(double cantidad) { //
        if (cantidad <= saldo) { //
            saldo -= cantidad; //
        } else { //
            System.out.println("Fondos insuficientes."); //
        } //
    } //

    public void mostrarInformacion() { //
        System.out.println("Titular: " + titular); //
        System.out.println("Número de cuenta: " + numeroCuenta); //
        System.out.println("Saldo actual: $" + saldo); //
    } //
}