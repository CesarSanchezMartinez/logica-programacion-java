package jel;
public class JE1 {

    public static void main(String[] args) {
        CuentaBancaria cuenta1 = new CuentaBancaria("Cesar Sanchez Martinez", 1000.0, "24598");
        cuenta1.depositar(500);
        cuenta1.retirar(200);
        cuenta1.mostrarInformacion();
        System.out.println("Cesar Sanchez Martinez - 24598 - 3C");
    }

}